# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: C:\adc_system\vitis_part\lwIP_example_system_system\_ide\scripts\systemdebugger_lwip_example_system_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source C:\adc_system\vitis_part\lwIP_example_system_system\_ide\scripts\systemdebugger_lwip_example_system_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent JTAG-HS3 210299BC2A56" && level==0 && jtag_device_ctx=="jsn-JTAG-HS3-210299BC2A56-23727093-0"}
fpga -file C:/adc_system/vitis_part/lwIP_example_system/_ide/bitstream/led_blinky_wrapper_adc_stream.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/hw/led_blinky_wrapper_adc_stream.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source C:/adc_system/vitis_part/lwIP_example_system/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow C:/adc_system/vitis_part/lwIP_example_system/Debug/lwIP_example_system.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
