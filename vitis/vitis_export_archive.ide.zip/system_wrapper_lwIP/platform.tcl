# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\adc_system\vitis_part\system_wrapper_lwIP\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\adc_system\vitis_part\system_wrapper_lwIP\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {system_wrapper_lwIP}\
-hw {C:\adc_system\adc_blinky\led_blinky_wrapper.xsa}\
-out {C:/adc_system/vitis_part}

platform write
domain create -name {freertos10_xilinx_ps7_cortexa9_0} -display-name {freertos10_xilinx_ps7_cortexa9_0} -os {freertos10_xilinx} -proc {ps7_cortexa9_0} -runtime {cpp} -arch {32-bit} -support-app {freertos_lwip_echo_server}
platform generate -domains 
platform active {system_wrapper_lwIP}
domain active {zynq_fsbl}
domain active {freertos10_xilinx_ps7_cortexa9_0}
platform generate -quick
bsp reload
bsp config dhcp_does_arp_check "false"
bsp config lwip_dhcp "false"
bsp write
bsp reload
catch {bsp regenerate}
platform generate
platform clean
platform generate
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
bsp reload
bsp reload
bsp config tcp_snd_buf "8192"
bsp config tcp_snd_buf "23360"
bsp config tcp_wnd "23360"
bsp write
bsp reload
catch {bsp regenerate}
platform generate -domains freertos10_xilinx_ps7_cortexa9_0 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper_adc_bringup.xsa}
platform generate
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper_adc_stream.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper_mega_adc_test.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/mega_adc_test.xsa}
platform generate -domains 
platform clean
platform generate
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/adc_with_dma.xsa}
platform generate
platform clean
platform generate
platform config -updatehw {C:/adc_system/adc_blinky/adc_correct_dma_1.xsa}
platform generate -domains 
bsp reload
bsp reload
domain active {zynq_fsbl}
bsp reload
bsp reload
bsp reload
domain active {freertos10_xilinx_ps7_cortexa9_0}
bsp reload
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/adc_axi_ila.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/adc_axi_ila.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/adc_axi_v2.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/adc_axi_v3_ila.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/adc_axi_v3_ila.xsa}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/dma_investig.xsa}
platform generate -domains 
domain active {zynq_fsbl}
domain active {freertos10_xilinx_ps7_cortexa9_0}
bsp reload
bsp reload
bsp reload
domain active {zynq_fsbl}
bsp reload
catch {platform remove adc_system_bringup}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
domain active {freertos10_xilinx_ps7_cortexa9_0}
domain active {zynq_fsbl}
platform generate -domains 
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
platform active {system_wrapper_lwIP}
platform config -updatehw {C:/adc_system/adc_blinky/led_blinky_wrapper.xsa}
platform generate -domains 
