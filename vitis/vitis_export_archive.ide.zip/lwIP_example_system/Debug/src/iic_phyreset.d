src/iic_phyreset.o src/iic_phyreset.o: ../src/iic_phyreset.c \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
