################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LD_SRCS += \
../src/lscript.ld 

C_SRCS += \
../src/adc_hw.c \
../src/adc_stream.c \
../src/ads127l14_spi.c \
../src/console.c \
../src/device_gpio.c \
../src/iic_phyreset.c \
../src/led_status.c \
../src/main.c \
../src/pga_spi.c 

OBJS += \
./src/adc_hw.o \
./src/adc_stream.o \
./src/ads127l14_spi.o \
./src/console.o \
./src/device_gpio.o \
./src/iic_phyreset.o \
./src/led_status.o \
./src/main.o \
./src/pga_spi.o 

C_DEPS += \
./src/adc_hw.d \
./src/adc_stream.d \
./src/ads127l14_spi.d \
./src/console.d \
./src/device_gpio.d \
./src/iic_phyreset.d \
./src/led_status.d \
./src/main.d \
./src/pga_spi.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: ARM v7 gcc compiler'
	arm-none-eabi-gcc -Wall -O0 -g3 -c -fmessage-length=0 -MT"$@" -mcpu=cortex-a9 -mfpu=vfpv3 -mfloat-abi=hard -IC:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


