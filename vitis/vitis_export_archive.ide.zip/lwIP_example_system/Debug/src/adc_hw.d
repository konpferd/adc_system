src/adc_hw.o src/adc_hw.o: ../src/adc_hw.c ../src/adc_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOS.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOSConfig.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/projdefs.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portable.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/deprecated_definitions.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portmacro.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/mpu_wrappers.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/list.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/semphr.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_bdring.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_bd.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xdebug.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_cache.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_cache.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xgpio.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xgpio_l.h
../src/adc_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOS.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOSConfig.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/projdefs.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portable.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/deprecated_definitions.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portmacro.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/mpu_wrappers.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/list.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/semphr.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_bdring.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_bd.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xdebug.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_cache.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xaxidma_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_cache.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xgpio.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xgpio_l.h:
