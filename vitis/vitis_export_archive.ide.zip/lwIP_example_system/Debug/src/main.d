src/main.o src/main.o: ../src/main.c \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/netif/xadapter.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwipopts.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/sys.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/opt.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/debug.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/arch.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/cc.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/cpu.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/err.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/sys_arch.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOS.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOSConfig.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/projdefs.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portable.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/deprecated_definitions.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portmacro.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/mpu_wrappers.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/list.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/semphr.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/timers.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/netif.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip_addr.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/def.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip4_addr.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip6_addr.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/def.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/pbuf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/stats.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/mem.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/memp.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/memp_std.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/memp_priv.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/mem_priv.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip4.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/prot/ip4.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip6.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/prot/ip.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/netif/xtopology.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 ../src/platform_config.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 ../src/console.h ../src/adc_stream.h ../src/led_status.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h \
 ../src/adc_hw.h ../src/device_gpio.h ../src/ads127l14_spi.h \
 ../src/pga_spi.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/sleep.h
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/netif/xadapter.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwipopts.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/sys.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/opt.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/debug.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/arch.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/cc.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/cpu.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/err.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/arch/sys_arch.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOS.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/FreeRTOSConfig.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/projdefs.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portable.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/deprecated_definitions.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/portmacro.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/mpu_wrappers.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/list.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/task.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/semphr.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/queue.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/timers.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/netif.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip_addr.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/def.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip4_addr.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip6_addr.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/def.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/pbuf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/stats.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/mem.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/memp.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/memp_std.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/memp_priv.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/priv/mem_priv.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip4.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/prot/ip4.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/ip6.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/lwip/prot/ip.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/netif/xtopology.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h:
../src/platform_config.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
../src/console.h:
../src/adc_stream.h:
../src/led_status.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xscugic_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_exception.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_spinlock.h:
../src/adc_hw.h:
../src/device_gpio.h:
../src/ads127l14_spi.h:
../src/pga_spi.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/sleep.h:
