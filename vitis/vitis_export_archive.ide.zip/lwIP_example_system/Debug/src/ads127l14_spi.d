src/ads127l14_spi.o src/ads127l14_spi.o: ../src/ads127l14_spi.c \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xspips.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xspips_hw.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h \
 ../src/ads127l14_spi.h ../src/device_gpio.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h \
 C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/sleep.h
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xspips.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xstatus.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_types.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_assert.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xspips_hw.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters_ps.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/bspconfig.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xreg_cortexa9.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xpseudo_asm_gcc.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xparameters.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_printf.h:
../src/ads127l14_spi.h:
../src/device_gpio.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/xil_io.h:
C:/adc_system/vitis_part/system_wrapper_lwIP/export/system_wrapper_lwIP/sw/system_wrapper_lwIP/freertos10_xilinx_ps7_cortexa9_0/bspinclude/include/sleep.h:
